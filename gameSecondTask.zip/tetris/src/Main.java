public class Main {

    public static void main(String[] a) {

    World world = World.getInstance();
    world.startGame();
    }
}