public enum TetrominoeTypeNames {
    LTETROMINOE, REVERSELTETROMINOE, ITETROMINOE, ZTETROMINOE, REVERSEZTETROMINOE, CUBETETROMINOE, TTETROMINOE;

    public TetrominoeTypeNames getTetrominoeTypeNames(int i) {
        return values()[i];
    }

}