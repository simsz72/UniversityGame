public class Main {

    public static void main(String[] a) {

    World world = new World();
    World.createWorld();
    Renderer.renderGame();
    world.startGame();
    }
}