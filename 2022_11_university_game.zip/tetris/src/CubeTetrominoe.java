public class CubeTetrominoe extends Tetrominoes {

    public CubeTetrominoe(TetrominoeTypeNames type, int x, int y, World world) {
        super(type, world);
        this.points[0] = new Point(x, y);
        this.points[1] = new Point(x+1, y);
        this.points[2] = new Point(x, y-1);
        this.points[3] = new Point(x+1, y-1);
    }

    protected void rotate(Point[] pts) {
        }
    }
