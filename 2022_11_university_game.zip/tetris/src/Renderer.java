public class Renderer {

    public static void renderGame() {
        for (int y=0; y<20; y++) {
            for (int x=0; x<20; x++) {
                if (World.isWall(x,y))
                    System.out.print("#");
                else
                    System.out.print(" ");
            }
            System.out.println();
        }
    }
}
