public enum TetrominoeMoves {
    LEFT, RIGHT, DOWN, ROTATE}