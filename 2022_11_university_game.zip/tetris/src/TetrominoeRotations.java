public enum TetrominoeRotations {
    DEGREES0, DEGREES90, DEGREES180, DEGREES270;

    public static TetrominoeRotations getType(int i) {
        return values()[i];
    }

}