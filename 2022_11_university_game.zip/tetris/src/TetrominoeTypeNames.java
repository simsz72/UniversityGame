public enum TetrominoeTypeNames {
    LTETROMINOE, REVERSELTETROMINOE, ITETROMINOE, ZTETROMINOE, REVERSEZTETROMINOE, CUBETETROMINOE, TTETROMINOE;

    public static TetrominoeTypeNames getTetrominoeTypeNames(int i) {
        return values()[i];
    }

}